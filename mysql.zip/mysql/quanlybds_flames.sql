-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2023 at 05:44 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quanlybds_flames`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `ID` int(11) NOT NULL,
  `Username` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `Full_Name` varchar(50) DEFAULT NULL,
  `Role` varchar(30) DEFAULT NULL,
  `IsActive` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`ID`, `Username`, `Password`, `Full_Name`, `Role`, `IsActive`) VALUES
(1, 'lythihuyenchau', '123456', 'Lý Thị Huyền Châu', 'ADMIN', b'1'),
(2, 'nguyenvantuan', '123456', 'Nguyễn Văn Tuấn', 'SALE', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `ID` int(11) NOT NULL,
  `City_Name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`ID`, `City_Name`) VALUES
(1, 'Hồ Chí Minh'),
(2, 'Hà Nội'),
(3, 'Đà Nẵng'),
(4, 'Bình Dương'),
(5, 'Vũng Tàu'),
(6, 'Bắc Giang'),
(7, 'Đồng Nai'),
(8, 'Cà Mau'),
(9, 'Long An'),
(10, 'Cần Thơ');

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `ID` int(11) NOT NULL,
  `City_ID` int(11) NOT NULL,
  `District_Name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`ID`, `City_ID`, `District_Name`) VALUES
(1, 1, 'Quận Bình Tân'),
(2, 1, 'Quận Bình Thạnh'),
(3, 1, 'Quận 1'),
(4, 1, 'Quận 2'),
(5, 1, 'Quận 3'),
(6, 1, 'Quận 4'),
(7, 1, 'Quận 5'),
(8, 1, 'Quận 6'),
(9, 1, 'Quận 7'),
(10, 1, 'Quận 8'),
(11, 9, 'Huyện Bến Lức'),
(12, 9, 'Huyện Đức Hòa'),
(14, 9, 'Huyện Đức Huệ'),
(15, 4, 'Huyện Bến Cát'),
(16, 4, 'Huyện Dầu Tiếng'),
(17, 4, 'Huyện Thuận An'),
(18, 4, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `full_contract`
--

CREATE TABLE `full_contract` (
  `ID` int(11) NOT NULL,
  `Full_Contract_Code` varchar(10) DEFAULT NULL,
  `Customer_Name` varchar(50) NOT NULL,
  `Year_Of_Birth` int(11) DEFAULT NULL,
  `SSN` varchar(15) NOT NULL,
  `Customer_Address` varchar(100) DEFAULT NULL,
  `Mobile` varchar(15) DEFAULT NULL,
  `Property_ID` int(11) NOT NULL,
  `Date_Of_Contract` date DEFAULT NULL,
  `Price` decimal(18,0) DEFAULT NULL,
  `Deposit` decimal(18,0) DEFAULT NULL,
  `Remain` decimal(18,0) DEFAULT NULL,
  `Status` varchar(5) NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `full_contract`
--

INSERT INTO `full_contract` (`ID`, `Full_Contract_Code`, `Customer_Name`, `Year_Of_Birth`, `SSN`, `Customer_Address`, `Mobile`, `Property_ID`, `Date_Of_Contract`, `Price`, `Deposit`, `Remain`, `Status`, `updated_at`, `created_at`) VALUES
(1, 'FC22110001', 'Lý Thị Huyền Châu', 1990, '301198908', '45 Trần Hưng Đạo, Quận 5, Thành phố Hồ Chí Minh', '0919686576', 1, '2022-11-01', 1000000000, 100000000, 900000000, '1', '2023-11-22 15:28:40', '2023-11-22 15:29:30'),
(2, 'FC22110002', 'Trần Công Anh', 1989, '404948494', '36 Lê Văn Sỹ, Quận 3, TP.HCM', '0967686878', 2, '2022-11-02', 2000000000, 200000000, 1800000000, '1', '2023-11-22 15:28:40', '2023-11-22 15:29:30'),
(15, 'HD23110001', 'Nguyễn Tất Hiển', 2003, '555', '17 Lê Trọng Tấn, quận Tân Phú', '0901822630', 1, '2023-11-22', 50000, 50000, 50000, '0', '2023-11-22 09:12:24', '2023-11-22 09:12:24'),
(16, 'HD23110002', 'Nguyễn Tất Hiển', 2003, '555', '17 Lê Trọng Tấn, quận Tân Phú', '0901822630', 1, '2023-11-22', 50000, 50000, 50000, '0', '2023-11-22 09:12:39', '2023-11-22 09:12:39');

--
-- Triggers `full_contract`
--
DELIMITER $$
CREATE TRIGGER `TG_FULLCONTRACT_INSERT_AUTOCODE` AFTER INSERT ON `full_contract` FOR EACH ROW BEGIN
    DECLARE THANGHT VARCHAR(2);
    DECLARE NAMHT VARCHAR(2);
    DECLARE MSHD VARCHAR(10);
    DECLARE MAX_VALUE INT;

    SET THANGHT = DATE_FORMAT(NOW(), '%m');
    SET NAMHT = RIGHT(YEAR(NOW()), 2);

    IF EXISTS (SELECT 1 FROM Property WHERE LEFT(Property_Code, 2) = NAMHT) THEN
        SET MAX_VALUE = (SELECT MAX(CAST(RIGHT(Property_Code, 4) AS SIGNED)) FROM Property WHERE LEFT(Property_Code, 2) = NAMHT) + 1;
    ELSE
        SET MAX_VALUE = 1;
    END IF;

    SET MSHD = CONCAT('FC', THANGHT, NAMHT, LPAD(MAX_VALUE, 4, '0'));

    UPDATE Property SET Property_Code = MSHD WHERE ID = NEW.ID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `TG_HD_INSERT_AUTOCODE` BEFORE INSERT ON `full_contract` FOR EACH ROW BEGIN
    DECLARE NAMHT VARCHAR(2);
    DECLARE THANGHT VARCHAR(2);
    DECLARE MAX_VAL INT;
    DECLARE MSHD VARCHAR(11);

    SET NAMHT = RIGHT(YEAR(NOW()), 2);
    SET THANGHT = LPAD(MONTH(NOW()), 2, '0');

    -- Check for the existence of records with a specific year
    IF EXISTS (SELECT 1 FROM full_contract WHERE SUBSTRING(Full_Contract_Code, 3, 2) = NAMHT) THEN
        SET MAX_VAL = (SELECT MAX(CAST(RIGHT(Full_Contract_Code, 4) AS SIGNED)) FROM full_contract WHERE SUBSTRING(Full_Contract_Code, 3, 2) = NAMHT) + 1;
    ELSE 
        SET MAX_VAL = 1;
    END IF;

    SET MSHD = CONCAT('HD', NAMHT, THANGHT, LPAD(MAX_VAL, 4, '0'));
    SET NEW.Full_Contract_Code = MSHD;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `installment_contract`
--

CREATE TABLE `installment_contract` (
  `ID` int(11) NOT NULL,
  `Installment_Contract_Code` varchar(10) DEFAULT NULL,
  `Customer_Name` varchar(50) NOT NULL,
  `Year_Of_Birth` int(11) DEFAULT NULL,
  `SSN` varchar(15) NOT NULL,
  `Customer_Address` varchar(100) DEFAULT NULL,
  `Mobile` varchar(15) DEFAULT NULL,
  `Property_ID` int(11) NOT NULL,
  `Date_Of_Contract` date DEFAULT NULL,
  `Installment_Payment_Method` varchar(10) NOT NULL DEFAULT 'Tháng',
  `Payment_Period` int(11) DEFAULT NULL,
  `Price` decimal(18,0) DEFAULT NULL,
  `Deposit` decimal(18,0) DEFAULT NULL,
  `Loan_Amount` decimal(18,0) DEFAULT NULL,
  `Taken` decimal(18,0) DEFAULT 0,
  `Remain` decimal(18,0) DEFAULT NULL,
  `Status` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `installment_contract`
--

INSERT INTO `installment_contract` (`ID`, `Installment_Contract_Code`, `Customer_Name`, `Year_Of_Birth`, `SSN`, `Customer_Address`, `Mobile`, `Property_ID`, `Date_Of_Contract`, `Installment_Payment_Method`, `Payment_Period`, `Price`, `Deposit`, `Loan_Amount`, `Taken`, `Remain`, `Status`) VALUES
(1, 'IC22110001', 'Lâm Bá Thắng', 1980, '123467647', '1 Lê Lợi, Quận 1, TP.HCM', '0918273378', 3, '2022-11-04', 'Tháng', 12, 5000000000, 500000000, 4500000000, 0, 4500000000, b'1');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(110, '2014_10_12_000000_create_users_table', 1),
(111, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(112, '2019_08_19_000000_create_failed_jobs_table', 1),
(113, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(114, '2023_11_22_062332_create_sinhviens_table', 1),
(115, '2023_11_22_072548_create_full_contracts_table', 1),
(116, '2023_11_22_085217_create_properties_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `ID` int(11) NOT NULL,
  `Property_Code` varchar(7) DEFAULT NULL,
  `Property_Name` varchar(50) DEFAULT NULL,
  `Property_Type_ID` int(11) NOT NULL,
  `Description` text DEFAULT NULL,
  `District_ID` int(11) NOT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Area` int(11) DEFAULT NULL,
  `Bed_Room` int(11) DEFAULT NULL,
  `Bath_Room` int(11) DEFAULT NULL,
  `Price` decimal(18,0) DEFAULT NULL,
  `Installment_Rate` float DEFAULT NULL,
  `Avatar` text DEFAULT NULL,
  `Album` text DEFAULT NULL,
  `Property_Status_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`ID`, `Property_Code`, `Property_Name`, `Property_Type_ID`, `Description`, `District_ID`, `Address`, `Area`, `Bed_Room`, `Bath_Room`, `Price`, `Installment_Rate`, `Avatar`, `Album`, `Property_Status_ID`) VALUES
(1, 'P220001', 'NHÀ PHỐ GARDEN KHANG ĐIỀN', 3, 'Nhà xây 1 trệt, 2 lầu, hoàn thiện bên ngoài kính cường lực, sơn nước chống rêu mốc chất lượng, có cửa kính cường lực, gara ô tô để xe thoải mái.', 1, 'Dự án Melosa Garden, Quận 9, Hồ Chí Minh', 80, 2, 2, 1000000000, 7.99, 'ppc0001.jpg', 'ppc0002.jpg;ppc0003.jpg', 6),
(2, 'P220002', 'NHÀ 4 TẦNG 3 MẶT THOÁNG TRẦN HƯNG ĐẠO Q1', 3, 'Bán nhà trung tâm Quận 1 đoạn đẹp nhất đường Trần Hưng Đạo.', 1, 'Đường Trần Hưng Đạo, Quận 1, Hồ Chí Minh', 78, 2, 2, 2000000000, 7.99, 'ppc0004.jpg', 'ppc0005.jpg;ppc0006.jpg', 6),
(3, 'P220003', 'LAVITA CHARM', 2, 'Trong làn gió mát rượi, hương thơm cỏ cây tại Lavita Charm hòa theo từng bước chân sẽ đưa bạn trở về với không gian sống bình yên, tách biệt khỏi sự huyên náo của chốn phồn hoa. Lavita Charm như một nốt trầm yên ả của điệu nhạc du dương cho cảm xúc thăng hoa và nuôi dưỡng đam mê bất tận, đem đến nguồn vui, nguồn cảm hứng mới cho cuộc sống mỗi ngày.', 2, 'Dự án Lavita Charm, Đường 1, Phường Trường Thọ, Thủ Đức, Hồ Chí Minh', 120, 4, 4, 5000000000, 7.99, 'ppc0007.jpg', 'ppc0008.jpg;', 7);

--
-- Triggers `property`
--
DELIMITER $$
CREATE TRIGGER `TG_BDS_INSERT_AUTOCODE` BEFORE INSERT ON `property` FOR EACH ROW BEGIN
    DECLARE NAMHT VARCHAR(2);
    DECLARE THANGHT VARCHAR(2);
    DECLARE MAX_VAL INT;
    DECLARE MSBDS VARCHAR(11);

    SET NAMHT = RIGHT(YEAR(NOW()), 2);
    SET THANGHT = LPAD(MONTH(NOW()), 2, '0');

    -- Check for the existence of records with a specific year
    IF EXISTS (SELECT 1 FROM property WHERE SUBSTRING(Property_Code, 2, 2) = NAMHT) THEN
        SET MAX_VAL = (SELECT MAX(CAST(RIGHT(Property_Code, 4) AS SIGNED)) FROM property WHERE SUBSTRING(Property_Code, 2, 2) = NAMHT) + 1;
    ELSE 
        SET MAX_VAL = 1;
    END IF;

    SET MSBDS = CONCAT('BDS', THANGHT, NAMHT, LPAD(MAX_VAL, 4, '0'));
    SET NEW.Property_Code = MSBDS;

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `TG_PROPERTY_INSERT_AUTOCODE` AFTER INSERT ON `property` FOR EACH ROW BEGIN
    DECLARE THANGHT VARCHAR(2);
    DECLARE NAMHT VARCHAR(2);
    DECLARE MSHD VARCHAR(10);
    DECLARE MAX_VALUE INT;

    SET THANGHT = DATE_FORMAT(NOW(), '%m');
    SET NAMHT = RIGHT(YEAR(NOW()), 2);

    IF EXISTS (SELECT 1 FROM Property WHERE LEFT(Property_Code, 2) = NAMHT) THEN
        SET MAX_VALUE = (SELECT MAX(CAST(RIGHT(Property_Code, 4) AS SIGNED)) FROM Property WHERE LEFT(Property_Code, 2) = NAMHT) + 1;
    ELSE
        SET MAX_VALUE = 1;
    END IF;

    SET MSHD = CONCAT('HD', THANGHT, NAMHT, LPAD(MAX_VALUE, 4, '0'));

    UPDATE Property SET Property_Code = MSHD WHERE ID = NEW.ID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `property_service`
--

CREATE TABLE `property_service` (
  `ID` int(11) NOT NULL,
  `Service_ID` int(11) NOT NULL,
  `Property_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_service`
--

INSERT INTO `property_service` (`ID`, `Service_ID`, `Property_ID`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 1, 2),
(6, 2, 2),
(7, 1, 3),
(8, 3, 3),
(9, 4, 3),
(15, 1, 11),
(16, 2, 11);

-- --------------------------------------------------------

--
-- Table structure for table `property_status`
--

CREATE TABLE `property_status` (
  `ID` int(11) NOT NULL,
  `Property_Status_Name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_status`
--

INSERT INTO `property_status` (`ID`, `Property_Status_Name`) VALUES
(1, 'Đang bán'),
(2, 'Đã bán thanh toán một lần'),
(3, 'Đã bán trả góp'),
(4, 'Không hiển thị'),
(5, 'Hết hạn để bán'),
(6, 'Đang cọc đầy đủ'),
(7, 'Đang cọc trả góp');

-- --------------------------------------------------------

--
-- Table structure for table `property_type`
--

CREATE TABLE `property_type` (
  `ID` int(11) NOT NULL,
  `Property_Type_Name` varchar(50) DEFAULT NULL,
  `Property_Amount` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_type`
--

INSERT INTO `property_type` (`ID`, `Property_Type_Name`, `Property_Amount`) VALUES
(1, 'Chung cư', 1),
(2, 'Căn hộ dịch vụ', 1),
(3, 'Nhà riêng', 1),
(4, 'Villa', 0),
(5, 'Studio', 0),
(6, 'Office', 0);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `ID` int(11) NOT NULL,
  `Service_Name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`ID`, `Service_Name`) VALUES
(1, 'Ban công'),
(2, 'Thang máy'),
(3, 'Nhà bếp'),
(4, 'Hồ bơi'),
(5, 'Wifi'),
(6, 'Chỗ đậu xe');

-- --------------------------------------------------------

--
-- Table structure for table `sinhviens`
--

CREATE TABLE `sinhviens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `MaSV` varchar(191) NOT NULL,
  `HoTen` varchar(191) NOT NULL,
  `NgaySinh` date NOT NULL,
  `GioiTinh` varchar(191) NOT NULL,
  `DiaChi` varchar(191) NOT NULL,
  `SoDT` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_District_City` (`City_ID`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `full_contract`
--
ALTER TABLE `full_contract`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_Full_Contract_Property` (`Property_ID`);

--
-- Indexes for table `installment_contract`
--
ALTER TABLE `installment_contract`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_Installment_Contract_Property` (`Property_ID`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_Property_District` (`District_ID`),
  ADD KEY `FK_Property_Property_Status` (`Property_Status_ID`),
  ADD KEY `FK_Property_Property_Type` (`Property_Type_ID`);

--
-- Indexes for table `property_service`
--
ALTER TABLE `property_service`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `property_status`
--
ALTER TABLE `property_status`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `property_type`
--
ALTER TABLE `property_type`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `sinhviens`
--
ALTER TABLE `sinhviens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `full_contract`
--
ALTER TABLE `full_contract`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `installment_contract`
--
ALTER TABLE `installment_contract`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `property_service`
--
ALTER TABLE `property_service`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `property_status`
--
ALTER TABLE `property_status`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `property_type`
--
ALTER TABLE `property_type`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sinhviens`
--
ALTER TABLE `sinhviens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `district`
--
ALTER TABLE `district`
  ADD CONSTRAINT `FK_District_City` FOREIGN KEY (`City_ID`) REFERENCES `city` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `full_contract`
--
ALTER TABLE `full_contract`
  ADD CONSTRAINT `FK_Full_Contract_Property` FOREIGN KEY (`Property_ID`) REFERENCES `property` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `installment_contract`
--
ALTER TABLE `installment_contract`
  ADD CONSTRAINT `FK_Installment_Contract_Property` FOREIGN KEY (`Property_ID`) REFERENCES `property` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `property`
--
ALTER TABLE `property`
  ADD CONSTRAINT `FK_Property_District` FOREIGN KEY (`District_ID`) REFERENCES `district` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_Property_Property_Status` FOREIGN KEY (`Property_Status_ID`) REFERENCES `property_status` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_Property_Property_Type` FOREIGN KEY (`Property_Type_ID`) REFERENCES `property_type` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
