DELIMITER //

CREATE TRIGGER TG_HD_INSERT_AUTOCODE
BEFORE INSERT ON full_contract
FOR EACH ROW
BEGIN
    DECLARE NAMHT VARCHAR(2);
    DECLARE THANGHT VARCHAR(2);
    DECLARE MAX_VAL INT;
    DECLARE MSHD VARCHAR(11);

    SET NAMHT = RIGHT(YEAR(NOW()), 2);
    SET THANGHT = LPAD(MONTH(NOW()), 2, '0');

    -- Check for the existence of records with a specific year
    IF EXISTS (SELECT 1 FROM full_contract WHERE SUBSTRING(Full_Contract_Code, 3, 2) = NAMHT) THEN
        SET MAX_VAL = (SELECT MAX(CAST(RIGHT(Full_Contract_Code, 4) AS SIGNED)) FROM full_contract WHERE SUBSTRING(Full_Contract_Code, 3, 2) = NAMHT) + 1;
    ELSE 
        SET MAX_VAL = 1;
    END IF;

    SET MSHD = CONCAT('HD', NAMHT, THANGHT, LPAD(MAX_VAL, 4, '0'));
    SET NEW.Full_Contract_Code = MSHD;

END //

DELIMITER ;