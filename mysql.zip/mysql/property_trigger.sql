DELIMITER //

CREATE TRIGGER TG_BDS_INSERT_AUTOCODE
BEFORE INSERT ON property
FOR EACH ROW
BEGIN
    DECLARE NAMHT VARCHAR(2);
    DECLARE THANGHT VARCHAR(2);
    DECLARE MAX_VAL INT;
    DECLARE MSBDS VARCHAR(11);

    SET NAMHT = RIGHT(YEAR(NOW()), 2);
    SET THANGHT = LPAD(MONTH(NOW()), 2, '0');

    -- Check for the existence of records with a specific year
    IF EXISTS (SELECT 1 FROM property WHERE SUBSTRING(Property_Code, 2, 2) = NAMHT) THEN
        SET MAX_VAL = (SELECT MAX(CAST(RIGHT(Property_Code, 4) AS SIGNED)) FROM property WHERE SUBSTRING(Property_Code, 2, 2) = NAMHT) + 1;
    ELSE 
        SET MAX_VAL = 1;
    END IF;

    SET MSBDS = CONCAT('BDS', THANGHT, NAMHT, LPAD(MAX_VAL, 4, '0'));
    SET NEW.Property_Code = MSBDS;

END //

DELIMITER ;